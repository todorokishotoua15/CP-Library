#include <bits/stdc++.h>
using namespace std;

#define nl "\n"

class DCar {
	// data
private:
	double fuelEff, fuel;

public:
	// constructor
	DCar() {
		fuelEff = -1;
		fuel = -1;
	}

	// methods
	void setVals(double fuelE, double amtFuel) {
		fuelEff = fuelE;
		fuel = amtFuel;
	}

	double getRange() {
		double val = fuelEff*fuel;
		
		return val;
	}
};

class ECar {
	//data
private:
	double batteryEff, battery;

public:
	// constructor
	ECar() {
		batteryEff = 0;
		battery = 0;
	}
	// method
	void setVals(double batteryE, double amtBattery) {
		batteryEff = batteryE;
		battery = amtBattery;
	}
	
	double getRange() {
		double val = (battery*1000)/(batteryEff);
		return val;
	}
};

class Cars {

private:

	vector<double> dcarvals, ecarvals;
	vector<DCar> dcars;
	vector<ECar> ecars;

public:
	// making classes
	Cars(vector<double> &dcarvalues, vector<double> &ecarvalues) {
		for (auto x : dcarvalues) dcarvals.push_back(x);
		for (auto x : ecarvalues) ecarvals.push_back(x);
		int i = 0;
		int sz1 = dcarvals.size();
		int sz2 = ecarvals.size();
		while (i < sz1) {
			DCar dcar;
			dcar.setVals(dcarvals[i], dcarvals[i+1]);
			dcars.push_back(dcar);
			i += 2;
		}
		i = 0;
		while (i < sz2) {
			ECar ecar;
			ecar.setVals(ecarvals[i], ecarvals[i+1]);
			ecars.push_back(ecar);
			i += 2;
		}
	}
	// method to get minimum and max range
	pair<double,double> dcarRange() {
		
		vector<double> dcarranges;
		for (auto x : dcars) {
			dcarranges.push_back(x.getRange());
		}
		double mi = *min_element(dcarranges.begin(), dcarranges.end());
		double ma = *max_element(dcarranges.begin(), dcarranges.end());

		return {mi,ma};
	}

	pair<double,double> ecarRange() {
		
		vector<double> ecarranges;
		for (auto x : ecars) {
			ecarranges.push_back(x.getRange());
		}
		double mi = *min_element(ecarranges.begin(), ecarranges.end());
		double ma = *max_element(ecarranges.begin(), ecarranges.end());

		return {mi,ma};
	}

};




int main() {

	vector<double> dcarvals(6), ecarvals(6);

	for (auto &s : dcarvals) cin >> s;
	for (auto &s : ecarvals) cin >> s;

	Cars cars(dcarvals,ecarvals);
	auto dcarrange = cars.dcarRange();
	auto ecarrange = cars.ecarRange();

	cout << "Diesel cars" << nl;
	cout << "Max range: ";
	printf("%0.2f\n", dcarrange.second);
	cout << "Min range: ";
	printf("%0.2f\n\n", dcarrange.first);

	cout << "Electric cars" << nl;
	cout << "Max range: ";
	printf("%0.2f\n", ecarrange.second);
	cout << "Min range: ";
	printf("%0.2f\n", ecarrange.first);

	return 0;
}