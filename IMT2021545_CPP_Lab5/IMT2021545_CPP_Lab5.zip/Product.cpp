#include<iostream>
#include<bits/stdc++.h>
using namespace std;
#include"Product.h"

// getters
int Product::getSize()
{
  return 0;
}

int Product::getDeltime()
{
  return 0;
}

int Product::getWidth()
{
  return 0;
}

string Product::getType()
{
  return type;
}

string Product::getBrand()
{
  return "";
}

int Product::getPrice()
{
  return price;
}

int Product::getRating()
{
  return 0;
}

int Product::getLength()
{
  return 0;
}
